import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:provider_shopper/models/cart.dart';
// import 'package:provider_shopper/models/catalog.dart';

class MyAppBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      title: Text('Sumit', style: Theme.of(context).textTheme.headline1),
      floating: true,
      actions: [
        IconButton(
          icon: Icon(Icons.menu),
          onPressed: () {},
        ),
      ],
    );
  }
}
